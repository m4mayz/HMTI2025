<?php get_header(); ?>

<h1><?php the_title(); ?></h1>
<p>Ini adalah konten dari index.php</p>

<?php get_footer(); ?>